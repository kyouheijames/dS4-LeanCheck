# STATUS.md — what is proved, what is convention, what is out of scope

The whole point of this layer is to NOT repeat the `ricci_curvature_flatness : True`
→ postulated-Ric pattern silently. Here is the exact epistemic status of every claim.

## A. Genuinely PROVED (real Lean theorems — algebra/linear algebra, no physics asserted)

| Theorem | Content |
|---------|---------|
| `freeDim_local` | Δχ(s=1) = (d−2)/2 — sanity of the dimension formula |
| `OmegaMin_antisymm`, `OmegaMin_diag_zero` | the symplectic invariant is antisymmetric with zero diagonal (non-unitarity seed) |
| `gammaT_zero_iff_local` | **γ_T = 0 ⟺ s = 1** — locality ⟺ conserved local T, as an iff |
| `nonlocal_of_ne_one` | s ≠ 1 ⇒ γ_T ≠ 0 (the non-local regime is well-defined) |
| `shadow_eq_conj_on_principal` | **shadow map = complex conjugation on the principal series** (CPT = shadow positivity) |
| `shadow_involutive`, `shadow_re_eq` | shadow is an involution preserving Re Δ = d/2 |
| `worth_of_principal` | the filter: principal + global + ghost ⇒ WorthInvestigating, with C2 derived |

These are the load-bearing structural facts. They pin down WHAT the theory is and
make "locality" and "CPT/shadow positivity" decidable predicates rather than prose.

## B. MODELING CONVENTION (faithful, but a choice — the zero set is the physics)

| Object | Convention | What is real vs. chosen |
|--------|-----------|-------------------------|
| `gammaT_free s = 2(s−1)` | linear order parameter | The **zero set {s=1}** is physical (conserved T iff s=1). The slope/coefficient is normalization — it is NOT the interacting anomalous dimension. |
| `freeDim` | (d−2s)/2 | Correct at Gaussian level; receives interacting corrections (Part 2). |

## C. OUT OF SCOPE — deliberately NOT formalized (honest gaps, by design)

| Gap | Why it is not here | Where it lives |
|-----|--------------------|----------------|
| Existence/construction of `(−∂²)ˢ` as a Fourier multiplier | analysis, not classification; Mathlib's fractional-Laplacian support is thin | optional future Lean, or just trusted |
| **Interacting γ_T(s)** | needs ε-expansion / large-N loop & conformal integrals — no QFT in Mathlib | **Part 2 (CAS)** |
| Sphere partition function → e^{iS_dS}, Gibbons–Hawking entropy sign | non-perturbative; not algebraic | Part 2/3 |
| **Averaging consistency** (does crossing + shadow positivity survive s-fluctuation) | infinite crossing system; no proof object exists | **Part 3 (SDPB)** — the actual test of your conjecture |

## The one-line summary

This Lean layer **certifies that a candidate IS a consistent dS/CFT* dual and reports
its locality**. It does **not** and cannot certify that the *fluctuating-locality*
average stays consistent — that is Part 3, and no type-checker can do it. Lean fixes
the goalposts; it does not take the shot.
